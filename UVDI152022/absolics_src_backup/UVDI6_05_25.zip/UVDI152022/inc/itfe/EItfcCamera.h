﻿
/*
 desc : The Interface Library for Align Camera (Basler or IDS)
*/

#pragma once

#include "../conf/global.h"
#include "../conf/define.h"
#include "../conf/luria.h"
#if (CUSTOM_CODE_UVDI15_LLS10 == DELIVERY_PRODUCT_ID || \
	 CUSTOM_CODE_UVDI15_LLS06 == DELIVERY_PRODUCT_ID)
#include "../../inc/conf/vision_uvdi15.h"
#elif (CUSTOM_CODE_GEN2I == DELIVERY_PRODUCT_ID)
#include "../../inc/conf/vision_gen2i.h"
#elif (CUSTOM_CODE_UVDI15 == DELIVERY_PRODUCT_ID || \
		CUSTOM_CODE_HDDI6 == DELIVERY_PRODUCT_ID)
#include "../../inc/conf/vision_uvdi15.h"
#endif

class AlignMotion;
#ifdef __cplusplus
extern "C"
{
#endif

/* --------------------------------------------------------------------------------------------- */
/*                        외부 함수 - < Camera - Common > < for Engine >                         */
/* --------------------------------------------------------------------------------------------- */

/*
 desc : Align Camera 재접속 수행
 parm : None
 retn : None
*/
API_IMPORT VOID uvEng_Camera_Reconnect();
/*
 desc : BIPS Server와 통신을 담당하는 Client 스레드 생성 및 실행
 parm : None
 retn : TRUE or FALSE
*/
API_IMPORT BOOL uvEng_Camera_UpdateSetParam();
/*
 desc : Grabbed Image가 존재하면, Edge Detection 수행
 변수 :	cam_id	- [in]  Camera Index (1 or 2)
 retn : Edge Detected된 영역의 직경 (지름) 값 반환 (단위: Pixel)
*/
API_IMPORT BOOL uvEng_Camera_RunEdgeDetect(UINT8 cam_id);
/*
 desc : Set the parameters of the strip maker and find in an image and take the specified measurements
 parm : cam_id	- [in]  Align Camera ID (1 or 2 or later)
		param	- [in]  Structures pointer with information to set up is stored
		result	- [out] Buffer in which the resulting value will be returned and stored.
 retn : TRUE or FALSE
*/
API_IMPORT BOOL uvEng_Camera_RunMarkerStrip(UINT8 cam_id, LPG_MSMP param, STG_MSMR &results);
/*
 desc : Edge Detection 검색된 개수 반환
 parm : cam_id	- [in]  Align Camera ID (1 or 2)
 변환 : 개수 반환. 실패할 경우, 0 이하 값
*/
API_IMPORT INT32 uvEng_Camera_GetEdgeDetectCount(UINT8 cam_id);
/*
 desc : 모델 크기 반환
 parm : cam_id	- [in]  Grabbed Image 정보가 발생된 Align Camera Index (1 or 2)
		index	- [in]  요청하고자 하는 모델의 위치 (Zero-based)
		flag	- [in]  0x00 : 가로  크기, 0x01 : 세로 크기
		unit	- [in]  0x00 : um, 0x01 : pixel
 retn : 크기 반환 (단위: um)
*/
API_IMPORT DOUBLE uvEng_Camera_GetMarkModelSize(UINT8 cam_id, UINT8 index, UINT8 flag, UINT8 unit);
/*
 desc : Edge Detection 검색된 결과 반환
 parm : cam_id	- [in]  Align Camera ID (1 or 2)
 retn : 결과 값이 저장된 포인터 반환
*/
API_IMPORT LPG_EDFR uvEng_Camera_GetEdgeDetectResults(UINT8 cam_id);
/*
 desc : Edge Detection 검색된 결과 값 중에서 찾고자 하는 객체 크기와 가장 근사한 값 반환
 parm : cam_id	- [in]  Align Camera ID (1 or 2)
		diameter- [in]  검색하고자 하는 크기 값 (단위: mm)
 retn : 결과 값이 저장된 포인터 반환
*/
API_IMPORT LPG_EDFR uvEng_Camera_GetEdgeDetectResultSearch(UINT8 cam_id, DOUBLE diameter);
/*
 desc : Geometric Model Find
 parm : cam_id	- [in]  Camera Index (1 or 2)
 retn : TRUE or FALSE
*/
API_IMPORT BOOL uvEng_Camera_RunModelFind(UINT8 cam_id, UINT8 mark_no); // 미사용
/*
 desc : 가장 최근 Grabbed Image의 매칭 검색 결과 구조체 포인터 반환
 parm : None
 retn : 객체 포인터 (매칭이 실패한 경우 NULL)
*/
API_IMPORT LPG_ACGR uvEng_Camera_GetLastGrabbedMark();
API_IMPORT BOOL uvEng_GetModelRadius(UINT8 cam_id, double& width, double& height, bool toPixelSize);
/*
 desc : 가장 최근 Grabbed Image의 매칭 검색 결과 구조체 포인터 반환
 parm : None
 retn : 객체 포인터 (매칭이 실패한 경우 NULL)
 이력 : 2021-05-25 (Modified by JinSoo.Kang: First released)
*/
API_IMPORT LPG_ACGR uvEng_Camera_GetLastGrabbedMarkEx();
/*
 desc : 가장 최근에 카메라 별로 Calibrated된 결과 중 Error 값이 저장된 데이터 반환
 parm : None
 retn : 매칭된 결과 값 반환
 이력 : 2021-05-25 (Modified by JinSoo.Kang: First released)
*/
API_IMPORT LPG_ACLR uvEng_Camera_GetLastGrabbedACam();
#if 0
/*
 desc : 기존 Grabbed Data 초기화
 parm : None
 retn : None
*/
API_IMPORT VOID uvEng_Camera_ResetGrabbedMark();
#endif
/*
 desc : 기존 Grabbed Image 초기화
 parm : None
 retn : None
*/
API_IMPORT VOID uvEng_Camera_TriggerMode(int camIdx, ENG_TRGM mode);
API_IMPORT VOID uvEng_Camera_ResetGrabbedImage();
API_IMPORT bool uvEng_Camera_RemoveLastGrab(int camIdx);

API_EXPORT LPG_ACGR uvEng_GetGrabUseMark(int camNum, STG_XMXY mark);

API_IMPORT bool uvEng_FixMoveOffsetUseImgID(int camNum, int imgID, double offsetX, double offsetY, bool set = false);
API_IMPORT bool uvEng_FixMoveOffsetUseMark(int camNum, STG_XMXY mark, double offsetX, double offsetY,bool set = false);


API_IMPORT bool  uvEng_Camera_SWGrab(int camIdx);
API_IMPORT ENG_TRGM uvEng_Camera_GetTriggerMode(int camIdx);
/*
 desc : Vision Camera Mode 설정
 parm : mode	- [in]  en_vccm_xxx
 retn : None
*/
API_IMPORT VOID uvEng_Camera_SetCamMode(ENG_VCCM mode);

/*
 desc : 현재 Vision Camera Mode 반환 (동작 값)
 parm : None
 retn : 동작 모드 값 반환
*/
API_IMPORT ENG_VCCM uvEng_Camera_GetCamMode();
/*
 desc : 현재 Vision Camera Mode가 Live View Mode인지 여부
 parm : None
 retn : TRUE or FALSE
*/
API_IMPORT BOOL uvEng_Camera_IsCamModeLive();
/*
 desc : 현재 Vision Camera Mode가 Calibration View Mode인지 여부
 parm : None
 retn : TRUE or FALSE
*/
API_IMPORT BOOL uvEng_Camera_IsCamModeCali();
/*
 desc : 현재 Vision Camera Mode가 Grabbed View Mode인지 여부
 parm : None
 retn : TRUE or FALSE
*/
API_IMPORT BOOL uvEng_Camera_IsCamModeGrab();
/*
 desc : 가장 최근에 Edge Detection된 이미지에서 특정 영역만 추출해서 Bitmap Image로 등록
		즉, Mark Template 이미지로 등록
 parm : cam_id	- [in]  Align Camera ID (1 or Later)
		area	- [in]  추출하고자 하는 영역 정보가 저장된 픽셀 위치 값
		type	- [in]  0x00 : Edge, 0x02 : Line, 0x02 : Match, 0x03 : Grab
		file	- [in]  Mark Template를 저장하려는 파일 이름 (전체 경로 포함)
 retn : TRUE or FALSE
*/
API_IMPORT BOOL uvEng_Camera_SaveGrabbedMarkToFile(UINT8 cam_id, LPRECT area, UINT8 type, PTCHAR file);


/*
 desc : 현재 Grabbed된 이미지 출력 및 저장 (Bitmap을 이용하여 출력)
 parm : hdc		- [in]  이미지가 출력 대상 context
		draw	- [in]  이미지가 출력될 영역 (부모 윈도 기준 상대 좌표)
		cam_id	- [in]  Camera Index (1 or 2)
 retn : None
*/
API_IMPORT VOID uvEng_Camera_DrawGrabBitmap(HDC hdc, RECT draw, UINT8 cam_id=0x01);
/*
 desc : Draw the strip information in the current grabbed image
 parm : hdc		- [in]  The handle of context
		draw	- [in]  The area in which the image is output
		cam_id	- [in]  Camera Index (1 or 2)
		param	- [in]  Strip output information
 retn : None
*/
API_IMPORT VOID uvEng_Camera_DrawStripBitmap(HDC hdc, RECT draw, UINT8 cam_id, LPG_MSMP param);
/*
 desc : Grabbed Mark의 처리된 개수 반환
 변수 :	None
 retn : 처리된 마크 개수 반환
*/
API_IMPORT UINT16 uvEng_Camera_GetGrabbedCount(int* camNum=nullptr);
/*
 desc : 로컬 시스템 (저장소)에 저장되어 있는 패턴 매칭 원본 이미지 적재
 parm : cam_id		- [in]  Camera Index (0x01 ~ MAX_INSTALL_CAMERA_COUNT)
		speed		- [in]  0 - Very Low, 1 - Low, 2 - Medium, 3 - High, 4 - Very High
		detail_level- [in]  등록된 모델 이미지와 Grabbed Image이미지의 Edge 영역에 대한 비교 정도 값
							값이 클수록 상세히 비교하지만, 속도는 많이 느려지짐
							LOW보다 HIGH로 갈수록 더 많은 Edge를 가지고 비교하게 됨
							0 (M_MEDIUM), 1 (M_HIGH), 2 (M_VERY_HIGH)
		smooth		- [in]  0.0f - 기본 값, 1.0f ~ 100.0f
							기본 값은 50이지만, 100으로 갈수록 엣지의 강도가 센것만 나타납니다.
		model		- [in]  Model Type 즉, circle, square, rectangle, cross, diamond, triangle
		param		- [in]  총 5개의 Parameter Values (unit : um)
		count		- [in]  등록하고자 하는 모델의 개수
		아래 2개의 값이 0 값이면 파라미터 적용되지 않음
		scale_min	- [in]  검색 대상의 크기 범위 값 설정 (최소한 이 값 비율보다 커야 됨. 범위: 0.5 ~ 1.0)
		scale_max	- [in]  검색 대상의 크기 범위 값 설정 (최대한 이 값 비율보다 작아야 됨. 범위: 1.0 ~ 1.0)
		score_min	- [in]  이 값 이하로는 검색할 수 없다 (입력되는 값은 percentage (0.0 ~ 100.0)
		score_tgt	- [in]  이 값 이하로는 검색할 수 없다 (입력되는 값은 percentage (0.0 ~ 100.0))
		name		- [in]  Model Name
		file		- [in]  모델 이미지가 저장된 파일 이름 (전체 경로 포함. 이미지 파일)
 retn : TRUE or FALSE
*/
API_IMPORT BOOL uvEng_Camera_SetModelDefine(UINT8 cam_id, UINT8 speed, UINT8 level, UINT8 count, DOUBLE smooth,
											LPG_CMPV model, UINT8 mark_no,
											DOUBLE scale_min=0.0f, DOUBLE scale_max=0.0f,
											DOUBLE score_min=0.0f, DOUBLE score_tgt=0.0f);

API_IMPORT BOOL uvEng_Camera_SetModelDefineEx(UINT8 cam_id, UINT8 speed, UINT8 level, UINT8 count, DOUBLE smooth,
	PUINT32 model, DOUBLE* param1, DOUBLE* param2,
	DOUBLE* param3, DOUBLE* param4, DOUBLE* param5,
	UINT8 mark_no, DOUBLE scale_min = 0.0f, DOUBLE scale_max = 0.0f,
	DOUBLE score_min = 0.0f, DOUBLE score_tgt = 0.0f, bool sameMark = false);

API_IMPORT BOOL uvEng_Camera_SetModelDefineLoad(UINT8 cam_id, UINT8 speed, UINT8 level, DOUBLE smooth,
												DOUBLE scale_min, DOUBLE scale_max,
												DOUBLE score_min, DOUBLE score_tgt,
												PTCHAR name, CStringArray &file);
/*
 desc : Mark 정보 설정 - MMF (MIL Model Find File)
 parm : cam_id	- [in]  Align Camera Index (1 or 2)
		name	- [in]  Model Name
		file	- [in]  모델 이미지 (MMF)가 저장된 파일 이름 (전체 경로 포함. 확장자 mmf)
 retn : TRUE or FALSE
*/
API_IMPORT BOOL uvEng_Camera_SetModelDefineMMF(UINT8 cam_id, PTCHAR name, PTCHAR mmf, CPoint m_MarkSizeP, CPoint m_MarkCenterP, UINT8 mark_no);

/*
 desc : Mark 정보 설정 - PAT (MIL PAT Find File)
 parm : cam_id	- [in]  Align Camera Index (1 or 2)
		name	- [in]  Model Name
		file	- [in]  모델 이미지 (PAT)가 저장된 파일 이름 (전체 경로 포함. 확장자 pat)
 retn : TRUE or FALSE
*/
API_IMPORT BOOL uvEng_Camera_SetModelDefinePAT(UINT8 cam_id, PTCHAR name, PTCHAR pat, CPoint m_MarkSizeP, CPoint m_MarkCenterP, UINT8 mark_no);


/*
 desc : Calibration Image가 존재하면, Align Mark 수행
 변수 :	cam_id	- [in]  Camera Index (1 or 2)
		mode	- [in]  0xff : Calibration Mode (얼라인 카메라 각도 측정하지 않음)
						0xfe : Align Camera Angle Measuring Mode (얼라인 카메라 각도 측정하기 위함)
 retn : Calirbated Image의 정보가 저장된 구조체 포인터 반환
*/
API_IMPORT LPG_ACGR uvEng_Camera_RunModelCali(UINT8 cam_id, UINT8 mode, UINT8 dlg_id, UINT8 mark_no, BOOL useMilDisp, UINT8 img_proc,int flipDir=-1); // default mode : 0xff
/*
 desc : Calibration 이미지 (검색된 결과)를 윈도 영역에 출력 수행 (Bitmap을 이용하여 출력)
 parm : hdc		- [in]  이미지가 출력 대상 context
		draw	- [in]  이미지가 출력될 영역 (부모 윈도 기준 상대 좌표)
 retn : None
*/
API_IMPORT VOID uvEng_Camera_SetAlignMotionPtr(AlignMotion& ptr);
API_IMPORT VOID uvEng_Camera_DrawCaliBitmap(HDC hdc, RECT draw);
/*
 desc : Outputs the most recently generated Buffer ID value to the window
 parm : hwnd	- [in]  Handle of window where the image is output
		draw	- [in]  The area of window where the image is output
		cam_id	- [in]  Align Camera ID (1 or 2)
		type	- [in]  0x00: Edge Detection, 0x01: Line Detection, 0x02: Strip Detection (Measurement)
 retn : None
*/
API_IMPORT VOID uvEng_Camera_DrawMBufID(HWND hwnd, RECT draw, UINT8 cam_id, UINT8 type=0x00);
/*
 desc : 검색된 Mark 이미지 윈도 영역에 출력 수행 (DC를 이용하여 bitmap 이미지로 출력)
 parm : hdc		- [in]  이미지가 출력 대상 context
		draw	- [in]  이미지가 출력될 영역 (부모 윈도 기준 상대 좌표)
		cam_id	- [in]  Camera Index (1 or 2)
		img_id	- [in]  Camera Grabbed Image Index (0 or Later)
 retn : TRUE or FALSE
*/
API_IMPORT BOOL uvEng_Camera_DrawMarkBitmap(HDC hdc, RECT draw, UINT8 cam_id, UINT8 img_id);
/*
 desc : Calibration 이미지 윈도 영역에 출력 수행
 parm : hdc		- [in]  이미지가 출력 대상 context
		draw	- [in]  이미지가 출력될 영역 (부모 윈도 기준 상대 좌표)
		grab	- [in]  grab 이미지가 저장된 구조체 포인터 (grab_data에 이미지가 정보가 반드시 저장되어 있어야 됨)
		find	- [in]  마크 검색 성공 여부 (검색됐더라도, 검색 결과 값에 따라 달라짐)
						0x00 - 검색 결과 실패, 0x01 - 검색 결과 성공
 retn : None
*/
API_IMPORT VOID uvEng_Camera_DrawMarkDataBitmap(HDC hdc, RECT draw, LPG_ACGR grab, UINT8 find,bool drawForce, UINT8 flipFlag = 0xff);
/*
 desc : 검색된 Mark 이미지 윈도 영역에 출력 수행 (MIL Buffer ID를 이용한 출력)
 parm : hdc		- [in]  이미지가 출력 대상 context
		draw	- [in]  이미지가 출력될 영역 (부모 윈도 기준 상대 좌표)
		cam_id	- [in]  Camera Index (1 or 2)
		img_id	- [in]  Camera Grabbed Image Index (0 or Later)
 retn : TRUE or FALSE
*/
API_IMPORT BOOL uvEng_Camera_DrawMarkMBufID(HWND hwnd, RECT draw, UINT8 cam_id, UINT8 hwndIdx, UINT8 img_id);
/*
 desc : Drawing - Examination Object Image (Bitmap을 이용하여 출력)
 parm : hdc		- [in]  이미지가 출력 대상 context
		draw	- [in]  이미지가 출력될 영역 (부모 윈도 기준 상대 좌표)
		grab_out- [in]  Grabbed Image 정보가 저장된 구조체 포인터 (바깥 링)
		grab_in	- [in]  Grabbed Image 정보가 저장된 구조체 포인터 (안쪽 원)
 retn : None
*/
API_IMPORT VOID uvEng_Camera_DrawGrabExamBitmap(HDC hdc, RECT draw, LPG_ACGR grab_out, LPG_ACGR grab_in);
/*
 desc : Mark Template가 등록되어 있는지 확인
 parm : mode	- [in]  0x00 : Expose, 0x01 : Vstep
		cam_id	- [in]  Camera Index (0x01 ~ MAX_INSTALL_CAMERA_COUNT)
 retn : TRUE - 등록되어 있다. FALSE - 등록되지 않았다.
*/
API_IMPORT BOOL uvEng_Camera_IsSetMarkModel(UINT8 mode=0x00, UINT8 cam_id=0x01, UINT8 fi_No = 0x00);
/*
 desc : Mark Pattern 등록 여부
 parm : cam_id	- [in]  Camera Index (0x01 ~ MAX_INSTALL_CAMERA_COUNT)
 retn : TRUE or FALSE
*/
API_IMPORT BOOL uvEng_Camera_IsSetMarkModelACam(UINT8 cam_id, UINT8 mark_no);
/*
 desc : Step (Vision 단차) Image가 존재하면, Align Mark 수행
 변수 :	cam_id	- [in]  Camera Index (1 or 2)
		counts	- [in]  검색 대상의 Mark 개수 (찾고자하는 마크 개수)
		angle	- [in]  각도 적용 여부 (TRUE : 각도 적용, FALSE : 각도 적용 없음)
						TRUE : 현재 카메라의 회전된 각도 구하기 위함, FALSE : 기존 각도 적용하여 회전된 각도 구함
		results	- [out] 검색된 결과 정보가 저장될 구조체 참조 포인터 (grabbed image buffer까지 복사해옴)
 retn : TRUE or FALSE
*/
API_IMPORT BOOL uvEng_Camera_RunModelStep(UINT8 cam_id, UINT16 count, BOOL angle, LPG_ACGR results, UINT8 dlg_id, UINT8 mark_no, UINT8 img_proc);
/*
 desc : Examination (Vision Align 검사 (측정)) Image가 존재하면, Align Shutting 검사 수행
 변수 :	results		- [out] 검색된 결과 정보가 저장될 구조체 참조 포인터 (grabbed image buffer까지 복사해옴)
 retn : TRUE or FALSE
*/
API_IMPORT BOOL uvEng_Camera_RunModelExam(LPG_ACGR results); // 미사용
/*
 desc : Grabbed Images 모두 Score 값이 유효한지 값 반환
 parm : set_score	- [in]  If the score of the searched mark is higher than this set score, it is valid
  							(If 0.0f is unchecked) 
 retn : TRUE : 유효함, FALSE : 유효하지 않음
 이력 : 2021-05-25 (Modified by JinSoo.Kang: First released)
*/
API_IMPORT BOOL uvEng_Camera_IsScoreValidAll(DOUBLE set_score);
/*
 desc : Global Mark 대상으로, 2 개의 검색된 마크 정보 반환
 parm : direct	- [in]  측정지점 (0 - 1번 마크와 3번 마크 간의 길이 값)
								 (1 - 2번 마크와 4번 마크 간의 길이 값)
								 (2 - 1번 마크와 2번 마크 간의 길이 값)
								 (3 - 3번 마크와 4번 마크 간의 길이 값)
								 (4 - 1번 마크와 4번 마크 간의 길이 값)
								 (5 - 2번 마크와 3번 마크 간의 길이 값)
		data1	- [out] 검색된 첫 번째 마크의 중심 위치에서 오차 값 (단위: mm)
		data2	- [out] 검색된 두 번째 마크의 중심 위치에서 오차 값 (단위: mm)
 retn : TRUE or FALSE
*/
API_IMPORT BOOL uvEng_Camera_GetGrabbedMarkDirect(ENG_GMDD direct, STG_DBXY &data1, STG_DBXY &data2);
/*
 desc : 전역 기준점 : 검색된 X 축 기준으로 2 개의 마크가 떨어진 위치 반환 (단위 : mm)
 parm : type	- [in]  X (노광) 축의 마크 간격 (0 - 1번 마크와 3번 마크 간의 길이 값)
												(1 - 2번 마크와 4번 마크 간의 길이 값)
												(2 - 1번 마크와 2번 마크 간의 길이 값)
												(3 - 3번 마크와 4번 마크 간의 길이 값)
												(4 - 1번 마크와 4번 마크 간의 길이 값)
												(5 - 2번 마크와 3번 마크 간의 길이 값)
 retn : X 축의 2개의 마크 떨어진 간격 (단위: mm) 반환
*/

API_IMPORT CAtlList <LPG_ACGR>* uvEng_Camera_GetGrabbedMarkAll();


API_IMPORT BOOL uvEng_Camera_TryEnterCS();

API_IMPORT VOID uvEng_Camera_ExitCS();




API_IMPORT DOUBLE uvEng_Camera_GetGrabbedMarkDist(ENG_GMDD direct);
/*
 desc : Global 4개의 Mark에 대해서 모두 유효한지 검사
 parm : multi_mark	- [in]  Multi Mark (다중 마크) 적용 여부
		set_score	- [in]  If the score of the searched mark is higher than this set score, it is valid
 							(If 0.0f is unchecked) 
 retn : TRUE (유효함) or FALSE (4개 중 1개라도 제대로 인식 안됨)
*/
API_IMPORT BOOL uvEng_Camera_IsGrabbedMarkValidAll(BOOL multi_mark, DOUBLE set_score, int* camNum=nullptr);
/*
 desc : Grabbed Image의 결과 반환
 parm : cam_id	- [in]  Camera Index (1 or 2)
		img_id	- [in]  Camera Grabbed Image Index (0 or Later)
 retn : grab data 반환
*/
API_IMPORT LPG_ACGR uvEng_Camera_GetGrabbedMark(UINT8 cam_id, UINT8 img_id);
/*
 desc : Grabbed Image의 데이터 반환
 parm : index	- [in]  가져오고자 하는 위치 (Zero based)
 retn : grab data 반환
*/
API_IMPORT LPG_ACGR uvEng_Camera_GetGrabbedMarkIndex(UINT8 index);
/*
 desc : Grabbed Image의 결과 수정
 parm : grab	- [in]  저장된 구조체 포인터
 retn : TRUE or FALSE
*/
API_IMPORT BOOL uvEng_Camera_SetGrabbedMark(LPG_ACGR grab);
/*
 desc : 사용자에 의해 수동으로 검색된 경우, 결과 값만 처리
 parm : grab	- [in]  사용자에 의해 수동으로 입력된 grabbed image 결과 정보가 저장된 구조체 포인터
		gmfr	- [in]  GMFR Data
		gmsr	- [in]  GMSR Data
 retn : TRUE or FALSE
*/
API_IMPORT BOOL uvEng_Camera_SetGrabbedMarkEx(LPG_ACGR grab, LPG_GMFR gmfr, LPG_GMSR gmsr);
/*
 desc : Align Mark 검색 방식 설정
 parm : method	- [in]  0x00 : 최적의 1개 반환, 0x01 : 다점 마크 기준으로 가중치를 부여하여 결과 반환
		count	- [in]  'method' 값이 1인 경우, 최종 검색될 Mark 개수 값 2 이상 값이어야 됨
 retn : None
*/
API_IMPORT VOID uvEng_Camera_SetMarkMethod(ENG_MMSM method, UINT8 count=0x00);

API_IMPORT UINT8 uvEng_SetMarkFoundCount(int camNum);

/*
 desc : 노광 모드 설정 즉, 직접 노광, 얼라인 노광, 보정 후 얼라인 노광
 parm : mode	- [in]  직접 노광 (0x00), 얼라인 노광 (0x01), 얼라인 카메라 보정 값 적용 후 얼라인 노광 (0x02)
 retn : None
*/
API_IMPORT VOID uvEng_Camera_SetAlignMode(ENG_AOEM mode);
/*
 desc : 현재 적재된 레시피의 마크 검색 조건 값 설정
 parm : score	- [in]  Score Rate
		scale	- [in]  Scale Rate
 retn : None
*/
API_IMPORT VOID uvEng_Camera_SetRecipeMarkRate(DOUBLE score, DOUBLE scale);
/*
 desc : 스테이지의 이동 방향 설정 (정방향 이동인지 / 역방향 이동인지 여부)
 parm : direct	- [in]  TRUE (정방향 이동 : 앞에서 뒤로 이동), FALSE (역방향 이동)
 retn : None
*/
API_IMPORT VOID uvEng_Camera_SetMoveStateDirect(BOOL direct);
/*
 desc : 얼라인 카메라의 Gain Level 값 설정
 parm : cam_id	- [in]  Camera Index (1 or 2)
		level	- [in] 0 ~ 255 (값이 클수록 밝게 처리)
 retn : TRUE or FALSE
*/
API_IMPORT BOOL uvEng_Camera_SetGainLevel(UINT8 cam_id, UINT8 level);
/*
 desc : 수동으로 이미지를 불러와서 데이터를 적재 합니다. (데모 모드에서 주로 사용 됨)
 parm : cam_id	- [in]  Camera Index (1 or 2)
		file	- [in]  전체 경로가 포함됨 265 grayscale bitmap 파일
 retn : TRUE or FALSE
*/
API_IMPORT BOOL uvEng_Camera_LoadImageFromFile(UINT8 cam_id, PTCHAR file);
/*
 desc : Grabbed Image 마다 표현된 마크의 개수가 여러 개인 경우, 마크 들이 분포된 영역의 크기 값 설정
 parm : width	- [in]  사각형 영역의 넓이 값 (단위: um)
		height	- [in]  사각형 영역의 높이 값 (단위: um)
 retn : None
*/
API_IMPORT VOID uvEng_Camera_SetMultiMarkArea(UINT32 width=0, UINT32 height=0);

/* --------------------------------------------------------------------------------------------- */
/*                        외부 함수 - < Camera - Common > < for Common >                         */
/* --------------------------------------------------------------------------------------------- */

/*
 desc : 현재 PLC가 연결되어 있는지 여부 확인
 변수 :	cam_id	- [in]  Align Camera Index (1 or 2)
 retn : TRUE or FALSE
*/
API_IMPORT BOOL uvCmn_Camera_IsConnected();
API_IMPORT BOOL uvCmn_Camera_IsConnectedACam(UINT8 cam_id);
/*
 desc : Align Camera의 Z 축 Limit (Up/Down)를 벗어났는지 여부
 parm : pos	- [in]  이동하고자 하는 Z 축 위치 값 (단위: mm)
 retn : TRUE or FALSE
*/
API_IMPORT BOOL uvCmn_Camera_IsZPosUpDownLimit(DOUBLE pos);


/* ----------------------------------------------------------------------------------------- */
/*                                 lk91 VISION 추가 함수                                     */
/* ----------------------------------------------------------------------------------------- */
API_IMPORT VOID uvEng_Camera_DrawLiveBitmap(HDC hdc, RECT draw, UINT8 cam_id, BOOL save = FALSE);
API_EXPORT VOID uvEng_Camera_DrawImageBitmap(int dispType, int Num, UINT8 cam_id, BOOL save = FALSE, int flipDir=-1);
API_EXPORT VOID uvEng_Camera_SetMarkLiveDispSize(CSize fi_size);
API_EXPORT VOID uvEng_Camera_SetCalbCamSpecDispSize(CSize fi_size);
API_EXPORT VOID uvEng_Camera_SetAccuracyMeasureDispSize(CSize fi_size);
API_EXPORT VOID uvEng_Camera_SetCalbStepDispSize(CSize fi_size);
API_EXPORT VOID uvEng_Camera_SetMMPMDispSize(CSize fi_size);
API_IMPORT VOID uvEng_Camera_SetDispType(UINT8 dispType);

API_EXPORT VOID uvCmn_Camera_MilSetMarkROI(UINT8 cam_id, CRect fi_rectSearhROI);

API_EXPORT BOOL uvCmn_Camera_RegistPat(UINT8 cam_id, CRect fi_rectArea, CString fi_filename, UINT8 mark_no);
API_EXPORT BOOL uvCmn_Camera_RegistMod(UINT8 cam_id, CRect fi_rectArea, CString fi_filename, UINT8 mark_no);
API_EXPORT BOOL uvCmn_Camera_RegistMMPM_AutoCenter(CRect fi_rectArea, UINT8 cam_id, UINT8 img_id);

API_EXPORT VOID uvCmn_Camera_InitSetMarkSizeOffset(UINT8 cam_id, TCHAR* file, UINT8 fi_findType, UINT8 mark_no);

API_EXPORT VOID uvCmn_Camera_PutMarkDisp(HWND hwnd, int fi_iNo, RECT draw, UINT8 cam_id, TCHAR* file, int fi_findType);

API_EXPORT BOOL uvCmn_Camera_PutSetMarkDisp(HWND hwnd, RECT draw, UINT8 cam_id, TCHAR* file, int fi_findType, DOUBLE fi_dRate);
//API_EXPORT VOID uvCmn_Camera_PatSetMark(HWND hwnd, int fi_iDispType, int fi_iNo, RECT draw, UINT8 cam_id, TCHAR* file);
//API_EXPORT VOID uvCmn_Camera_ModSetMark(HWND hwnd, int fi_iDispType, int fi_iNo, RECT draw, UINT8 cam_id, TCHAR* file);

API_EXPORT DOUBLE uvCmn_Camera_SetMarkSetDispRate(DOUBLE fi_dRate);
API_EXPORT DOUBLE uvCmn_Camera_GetMarkSetDispRate();
API_EXPORT CPoint uvCmn_Camera_GetMarkSize(UINT8 cam_id, int fi_No);
API_EXPORT CPoint uvCmn_Camera_GetMarkOffset(UINT8 cam_id, BOOL bNewOffset, int fi_No);
API_EXPORT BOOL uvCmn_Camera_MaskBufGet();
API_EXPORT UINT8 uvCmn_Camera_GetMarkFindMode(UINT8 cam_id, UINT8 mark_no);
API_EXPORT BOOL uvCmn_Camera_SetMarkFindMode(UINT8 cam_id, UINT8 find_mode, UINT8 mark_no);

API_EXPORT VOID uvCmn_Camera_SetMarkSize(UINT8 cam_id, CPoint fi_MarkSize, int setMode, int fi_No);
API_EXPORT VOID uvCmn_Camera_SetMarkOffset(UINT8 cam_id, CPoint fi_MarkCenter, int setOffsetMode, int fi_No);

API_EXPORT VOID uvCmn_Camera_SaveMask_MOD(UINT8 cam_id, UINT8 mark_no);
API_EXPORT VOID uvCmn_Camera_SaveMask_PAT(UINT8 cam_id, UINT8 mark_no);

API_EXPORT VOID uvCmn_Camera_PatMarkSave(UINT8 cam_id, CString fi_strFileName, UINT8 mark_no);
API_EXPORT VOID uvCmn_Camera_ModMarkSave(UINT8 cam_id, CString fi_strFileName, UINT8 mark_no);

API_EXPORT VOID uvCmn_Camera_MaskClear_MOD(UINT8 cam_id, CPoint fi_iSizeP, UINT8 mark_no);
API_EXPORT VOID uvCmn_Camera_MaskClear_PAT(UINT8 cam_id, CPoint fi_iSizeP, UINT8 mark_no);
API_EXPORT VOID uvCmn_Camera_CenterFind(int cam_id, int fi_length, int fi_curSmoothness, double* fi_NumEdgeMIN_X, double* fi_NumEdgeMAX_X, double* fi_NumEdgeMIN_Y, double* fi_NumEdgeMAX_Y, int* fi_NumEdgeFound, int fi_Mode);// fi_Mode(1:SetMark, 2:ManualAlign)

API_EXPORT VOID uvEng_Camera_SetDispMark(CWnd* pWnd);
API_EXPORT VOID uvEng_Camera_SetDispRecipeMark(CWnd* pWnd[2]);
API_EXPORT VOID uvEng_Camera_SetDispMarkSet(CWnd* pWnd);
API_EXPORT VOID uvEng_Camera_SetDispMMPM_AutoCenter(CWnd* pWnd);
API_EXPORT VOID uvEng_Camera_SetDisp(CWnd** pWnd, UINT8 fi_Mode); // 0x00:MarkLive, 0x01:CalibCameraSpec, 0x02:CalibExposure
API_EXPORT VOID uvEng_Camera_SetDispMMPM(CWnd* pWnd);
API_EXPORT VOID uvEng_Camera_SetDispExpo(CWnd* pWnd[4]);

API_IMPORT VOID uvEng_Camera_ClearShapes(int fi_iDispType);
API_EXPORT VOID uvEng_Camera_DrawOverlayDC(bool fi_bDrawFlag, int fi_iDispType, int fi_iNo);
API_EXPORT VOID uvEng_Camera_OverlayAddBoxList(int fi_iDispType, int fi_iNo, int fi_iLeft, int fi_iTop, int fi_iRight, int fi_iBottom, int fi_iStyle, int fi_color);
API_EXPORT VOID uvEng_Camera_OverlayAddCrossList(int fi_iDispType, int fi_iNo, int fi_iX, int fi_iY, int fi_iWdt1, int fi_iWdt2, int fi_color);
API_EXPORT VOID uvEng_Camera_OverlayAddTextList(int fi_iDispType, int fi_iNo, int fi_iX, int fi_iY, CString fi_sText, int fi_color, int fi_iSizeX, int fi_iSizeY, CString fi_sFont, bool fi_bEgdeFlag);
API_EXPORT VOID uvEng_Camera_OverlayAddLineList(int fi_iDispType, int fi_iNo, int fi_iSx, int fi_iSy, int fi_iEx, int fi_iEy, int fi_iStyle, int fi_color);
API_EXPORT VOID uvEng_Camera_OverlayAddCircleList(int fi_iDispType, int fi_iNo, int fi_iLeft, int fi_iTop, int fi_iRight, int fi_iBottom, int fi_color);
API_EXPORT VOID uvEng_Camera_DrawMarkInfo_UseMIL(UINT8 cam_id, UINT8 fi_smooth, UINT8 mark_no);

//API_EXPORT VOID uvEng_Camera_Mask_MarkSet(UINT8 cam_id, CPoint fi_point, CRect fi_rect, int fi_iBrushSize);
API_EXPORT VOID uvEng_Camera_Mask_MarkSet(UINT8 cam_id, CRect rectTmp, CPoint iTmpSizeP, CRect rectFill, int fi_color, bool bMask);

API_EXPORT VOID uvCmn_Camera_InitMask(UINT8 cam_id);
API_EXPORT VOID uvCmn_Camera_CloseSetMark();

API_EXPORT VOID uvCmn_Camera_MilZoomIn(int fi_iDispType, int cam_id, CRect rc);
API_EXPORT BOOL uvCmn_Camera_MilZoomOut(int fi_iDispType, int cam_id, CRect rc);
API_EXPORT VOID uvCmn_Camera_MilAutoScale(int fi_iDispType, int cam_id);

API_EXPORT VOID uvCmn_Camera_SetZoomDownP(int fi_iDispType, int cam_id, CPoint fi_point);
API_EXPORT VOID uvCmn_Camera_MoveZoomDisp(int fi_iDispType, int cam_id, CPoint fi_point, CRect fi_rect);
API_EXPORT CDPoint uvCmn_Camera_trZoomPoint(int fi_iDispType, int cam_id, CPoint fi_point);
//API_IMPORT BOOL uvEng_Camera_SetModelDefine_tot(UINT8 cam_id, UINT8 speed, UINT8 level, UINT8 count, DOUBLE smooth,
//		LPG_CMPV model, UINT8 fi_No, TCHAR* file,
//		DOUBLE scale_min = 0.0f, DOUBLE scale_max = 0.0f,
//		DOUBLE score_min = 0.0f, DOUBLE score_tgt = 0.0f);
API_IMPORT BOOL uvEng_Camera_MergeMark(UINT8 cam_id, LPG_CMPV value, UINT8 speed, UINT8 level, UINT8 count, DOUBLE smooth, UINT8 mark_no, TCHAR* file1, TCHAR* file2,
	TCHAR* RecipeName, DOUBLE scale_min = 0.0f, DOUBLE scale_max = 0.0f,
	DOUBLE score_min = 0.0f, DOUBLE score_tgt = 0.0f);
API_EXPORT BOOL uvCmn_Camera_ProcImage(UINT8 cam_id, UINT8 imgProc);

API_IMPORT CDPoint uvEng_Camera_RunModel_VisionCalib(UINT8 cam_id, UINT8 dlg_id, UINT8 mark_no, int* roi_left, int* roi_right, int* roi_top, int* roi_bottom, int row, int col);

#ifdef __cplusplus
}
#endif