﻿
/*
 desc : The Interface Library for Philoptics's Trigger Device
*/

#include "pch.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static CHAR THIS_FILE[] = __FILE__;
#endif


/* --------------------------------------------------------------------------------------------- */
/*                                           내부 함수                                           */
/* --------------------------------------------------------------------------------------------- */


#ifdef __cplusplus
extern "C"
{
#endif

/* --------------------------------------------------------------------------------------------- */
/*                             외부 함수 - < Trigger >  < for Engine >                           */
/* --------------------------------------------------------------------------------------------- */

/*
 desc : Trigger & Strobe Enable or Disable
 parm : enable	- [in]  TRUE : Enable, FALSE : Disable
 retn : TRUE or FALSE
*/
API_EXPORT BOOL uvEng_Trig_ReqTriggerStrobe(BOOL enable)
{
	if (!uvTrig_IsConnected() && GetConfig()->IsRunDemo())	return TRUE;
	return uvTrig_ReqTriggerStrobe(enable);
}

/*
 desc : 내부 트리거 설정
 parm : cam_id	- [in]  Align Camera Index (1 or 2)
 retn : TRUE or FALSE
*/
API_EXPORT BOOL uvEng_Trig_ReqEncoderLive(UINT8 cam_id)
{
	if (!uvTrig_IsConnected() && GetConfig()->IsRunDemo())	return TRUE;
	return uvTrig_ReqEncoderLive(cam_id);
}

/*
 desc : 내부 트리거 설정 초기화
 parm : None
 retn : TRUE or FALSE
*/
API_EXPORT BOOL uvEng_Trig_ReqEncoderOutReset()
{
	if (!uvTrig_IsConnected() || GetConfig()->IsRunDemo())	return TRUE;
	return uvTrig_ReqEncoderOutReset();
}

/*
 desc : 트리거 1개 발생 시킴 (Only Trigger Event)
 parm : ch_no	- [in]  채널 번호 (1 or 2)
 retn : TRUE or FALSE
*/
API_EXPORT BOOL uvEng_Trig_ReqTrigOutOneOnly(UINT8 ch_no)
{
	/* Check if it is in demo operation mode */
	if (!uvTrig_IsConnected() && GetConfig()->IsRunDemo())	return TRUE;
	return uvTrig_ReqTrigOutOneOnly(ch_no);
}

/*
 desc : 트리거 1개 발생 시킴 (Trigger Enable -> Trigger Event -> Trigger Disable)
 parm : ch_no	- [in]  채널 번호 (1 or 2)
		enable	- [in]  트리거 내보낸 이후 Disable 시킬지 여부
						트리거 1개 발생 후, 곧바로 트리거 Disable 할지 여부
 retn : TRUE or FALSE
*/
API_EXPORT BOOL uvEng_Trig_ReqTrigOutOne(UINT8 ch_no, BOOL enable)
{
	if (!uvTrig_IsConnected() && GetConfig()->IsRunDemo())	return TRUE;
	return uvTrig_ReqTrigOutOne(ch_no, enable);
}

#if 1
/*
 desc : Trigger Board에 처음 연결되고 난 이후, 환경 파일에 설정된 값으로 초기화 진행
 parm : None
 retn : TRUE or FALSE
*/
API_EXPORT BOOL uvEng_Trig_ReqInitUpdate()
{
	if (!uvTrig_IsConnected() && GetConfig()->IsRunDemo())	return TRUE;
	return uvTrig_ReqInitUpdate();
}
#endif
/*
 desc : 기존 등록된 4개 채널에 대한 Trigger Position 값 초기화 (최대 값) 수행
 parm : None
 retn : TRUE or FALSE
*/
API_EXPORT BOOL uvEng_Trig_ResetTrigPosAll()
{
	if (!uvTrig_IsConnected() && GetConfig()->IsRunDemo())	return TRUE;
	return uvTrig_ResetTrigPosAll();
}

/*
 desc : 현재 트리거의 위치 등록 값이 초기화 되었는지 여부
 parm : cam_id	- [in]  Align Camera Index (0x01 or 0x02)
		count	- [in]  채널 번호에 해당되는 검사할 트리거 등록 개수 (MAX: 16)
 retn : TRUE or FALSE
*/
API_EXPORT BOOL uvEng_Trig_IsTrigPosReset(UINT8 cam_id, UINT8 count)
{
	if (!uvTrig_IsConnected() && GetConfig()->IsRunDemo())	return TRUE;
	return uvTrig_IsTrigPosReset(cam_id, count);
}

/*
 desc : 현재 트리거에 송신될 명령 버퍼의 대기 개수가 임의 개수 이하인지 여부
 parm : count	- [in]  이 개수 미만이면 TRUE, 이상이면 FALSE
 retn : count 개수 미만 (미포함)이면 TRUE, 이상 (포함)이면 FALSE 반환
*/
API_EXPORT BOOL uvEng_Trig_IsSendCmdCountUnder(UINT16 count)
{
	if (!uvTrig_IsConnected() && GetConfig()->IsRunDemo())	return TRUE;
	return uvTrig_IsSendCmdCountUnder(count);
}

/*
 desc : 채널 별로 트리거 위치 등록
 parm : direct	- [in]  TRUE: 정방향 (전진), FALSE: 역방향 (후진)
		start	- [in]  트리거 저장 시작 위치 (0 ~ 15)
		count	- [in]  트리거 등록 개수 (1 ~ 16)
		pos		- [in]  트리거 등록 위치가 저장되어 있는 배열 포인터 (unit : 100 nm or 0.1 um)
		enable	- [in]  트리거 Enable or Disable
		clear	- [in]  트리거 위치 등록하면서 현재 Trigger Encoder 값을
						Clear (TRUE)할것인지 혹은 읽기 모드 (FALSE)를 유지할 것인지 여부
 retn : TRUE or FALSE
*/
API_EXPORT BOOL uvEng_Trig_ReqWriteAreaTrigPos(BOOL direct,
												UINT8 start1, UINT8 count1, PUINT32 pos1,
											   UINT8 start2, UINT8 count2, PUINT32 pos2,
											   ENG_TEED enable, BOOL clear)
{
	UINT8 i	= 0x00;
	UINT32 u32Trig[MAX_ALIGN_CAMERA][MAX_SCAN_MARK_COUNT]	= {NULL};

	if (!uvTrig_IsConnected() && GetConfig()->IsRunDemo())	return TRUE;

	for (; i<count1; i++)
	{
		u32Trig[0][i]	= pos1[i];	/* Align Camera 1 */
		u32Trig[1][i]	= pos2[i];	/* Align Camera 2 */
	}

	return uvTrig_ReqWriteAreaTrigPos(direct,
									  start1, count1, u32Trig[0],
									  start2, count2, u32Trig[1], enable, clear);
}

/*
 desc : 특정 채널에 트리거 위치 등록
 parm : cam_id	- [in]  Align Camera Index (0x01 or 0x02)
		start	- [in]  트리거 저장 시작 위치 (0 ~ 15)
		count	- [in]  트리거 등록 개수 (1 ~ 16)
		pos		- [in]  트리거 등록 위치가 저장되어 있는 배열 포인터 (unit : 100 nm or 0.1 um)
		enable	- [in]  트리거 Enable or Disable
		clear	- [in]  트리거 위치 등록하면서 현재 Trigger Encoder 값을
						Clear (TRUE)할것인지 혹은 읽기 모드 (FALSE)를 유지할 것인지 여부
 retn : TRUE or FALSE
*/
API_EXPORT BOOL uvEng_Trig_ReqWriteAreaTrigPosCh(UINT8 cam_id, UINT8 start, UINT8 count, PUINT32 pos,
												 ENG_TEED enable, BOOL clear)
{
	if (!uvTrig_IsConnected() && GetConfig()->IsRunDemo())	return TRUE;
	return uvTrig_ReqWriteAreaTrigPosCh(cam_id, start, count, pos, enable, clear);
}

/*
 desc : 기존에 입력된 Trigger 위치 값과 Trigger Board로부터 수신된 입력 값 비교
 parm : cam_id	- [in]  Align Camera Index (0x01 or 0x02)
		index	- [in]  트리거 저장 위치 (0x000 ~ 0x0f)
		pos		- [in]  트리거 값 (단위: 100 nm or 0.1 um)
 retn : TRUE or FALSE
*/
API_EXPORT BOOL uvEng_Trig_IsTrigPosEqual(UINT8 cam_id, UINT8 index, UINT32 pos)
{
	if (!uvTrig_IsConnected() && GetConfig()->IsRunDemo())	return TRUE;
	return uvTrig_IsTrigPosEqual(cam_id, index, pos);
}

/* --------------------------------------------------------------------------------------------- */
/*                             외부 함수 - < Trigger >  < for Common >                           */
/* --------------------------------------------------------------------------------------------- */

/*
 desc : 현재 PLC가 연결되어 있는지 여부 확인
 parm : None
 retn : TRUE or FALSE
*/
API_EXPORT BOOL uvCmn_Trig_IsConnected()
{
	if (!GetShMemTrigLink())	return FALSE;
	return GetShMemTrigLink()->is_connected;
}

/*
 desc : Trigger 내의 Strobe이 Enable or Disable 상태 값 반환
 parm : None
 retn : TRUE or FALSE
*/
API_EXPORT BOOL uvCmn_Trig_IsStrobEnable()
{
	if (GetConfig()->IsRunDemo())	return TRUE;
	return g_pMemTrig->GetMemMap()->IsTrigStrobEnabled();
}

/*
 desc : Trigger 내의 Strobe이 Enable or Disable 상태 값 반환
 parm : None
 retn : TRUE or FALSE
*/
API_EXPORT BOOL uvCmn_Trig_IsStrobDisable()
{
	if (GetConfig()->IsRunDemo())	return TRUE;
	return g_pMemTrig->GetMemMap()->IsTrigStrobDisabled();
}


#ifdef __cplusplus
}
#endif