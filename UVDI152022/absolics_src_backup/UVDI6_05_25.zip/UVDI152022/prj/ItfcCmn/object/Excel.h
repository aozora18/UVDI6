#pragma once

class CExcel
{
/* Constructor and Destructor */
public:

	CExcel();
	virtual ~CExcel();

/* Virtual Function */
protected:

public:


/* Member Parameter : Local */
protected:



/* Member Function : Local */
protected:


/* Member Function : Public */
public:

	/* Button */

	/* Combobox */

	/* Editbox */
	BOOL				ExcelCellName(UINT32 col, UINT32 row, PTCHAR name, UINT32 size);
};
